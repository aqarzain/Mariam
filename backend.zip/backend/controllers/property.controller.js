const httpStatus = require('http-status');
const { Property } = require('../models');
const APIError = require('../utils/APIError');

const getAllProperties = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const properties = await Property.paginate({
      page: parseInt(page),
      limit: parseInt(limit),
      order: [['created_at', 'DESC']]
    });
    res.json(properties);
  } catch (error) {
    next(error);
  }
};

const getAvailableProperties = async (req, res, next) => {
  try {
    const properties = await Property.findAll({ 
      where: { status: 'available' },
      include: ['contracts']
    });
    res.json(properties);
  } catch (error) {
    next(error);
  }
};

const createProperty = async (req, res, next) => {
  try {
    const propertyData = req.body;
    const property = await Property.create(propertyData);
    res.status(httpStatus.CREATED).json(property);
  } catch (error) {
    next(error);
  }
};

const updatePropertyStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const property = await Property.findByPk(id);
    if (!property) {
      throw new APIError({
        status: httpStatus.NOT_FOUND,
        message: 'العقار غير موجود'
      });
    }

    const updatedProperty = await property.updateStatus(status);
    res.json(updatedProperty);
  } catch (error) {
    next(error);
  }
};

module.exports = { 
  getAllProperties,
  getAvailableProperties,
  createProperty,
  updatePropertyStatus
};
