const authController = require('./auth.controller');
const propertyController = require('./property.controller');
const contractController = require('./contract.controller');

module.exports = {
  authController,
  propertyController,
  contractController
};
