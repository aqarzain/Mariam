const httpStatus = require('http-status');
const { Contract, Property } = require('../models');
const APIError = require('../utils/APIError');

const createContract = async (req, res, next) => {
  try {
    const contractData = req.body;
    const property = await Property.findByPk(contractData.property_id);

    if (!property.isAvailable()) {
      throw new APIError({
        status: httpStatus.BAD_REQUEST,
        message: 'العقار غير متاح حالياً'
      });
    }

    const contract = await Contract.create(contractData);
    res.status(httpStatus.CREATED).json(contract);
  } catch (error) {
    next(error);
  }
};

const terminateContract = async (req, res, next) => {
  try {
    const { id } = req.params;
    const contract = await Contract.findByPk(id);

    if (!contract) {
      throw new APIError({
        status: httpStatus.NOT_FOUND,
        message: 'العقد غير موجود'
      });
    }

    await contract.destroy();
    res.status(httpStatus.NO_CONTENT).send();
  } catch (error) {
    next(error);
  }
};

module.exports = { createContract, terminateContract };
