const httpStatus = require('http-status');
const { User } = require('../models');
const { jwt } = require('../config/auth');
const APIError = require('../utils/APIError');
const bcrypt = require('bcrypt');

const login = async (req, res, next) => {
  try {
    const { phone, password } = req.body;
    const user = await User.scope('withPassword').findOne({ where: { phone } });

    if (!user || !(await user.comparePassword(password))) {
      throw new APIError({
        status: httpStatus.UNAUTHORIZED,
        message: 'بيانات الدخول غير صحيحة'
      });
    }

    const token = user.generateToken();
    res.status(httpStatus.OK).json({ token, user: user.filterSafeFields() });
  } catch (error) {
    next(error);
  }
};

const register = async (req, res, next) => {
  try {
    const userData = req.body;
    const user = await User.create(userData);
    res.status(httpStatus.CREATED).json(user.filterSafeFields());
  } catch (error) {
    next(error);
  }
};

const refreshToken = async (req, res, next) => {
  try {
    const token = req.user.generateToken();
    res.status(httpStatus.OK).json({ token });
  } catch (error) {
    next(error);
  }
};

module.exports = { login, register, refreshToken };
