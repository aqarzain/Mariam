# دليل الكنترولرات

## هيكل API
| المسار                  | الوصف                  | الطريقة |
|-------------------------|------------------------|---------|
| `/auth/login`           | تسجيل الدخول           | POST    |
| `/properties`           | عرض العقارات           | GET     |
| `/properties/available` | العقارات المتاحة       | GET     |
| `/contracts`            | إنشاء عقد جديد         | POST    |

## نمط الاستجابة
```json
{
  "success": true,
  "data": {},
  "error": null
}
```

## أكواد الحالة
- 200: OK
- 201: Created
- 400: Bad Request
- 401: Unauthorized
- 404: Not Found
- 500: Internal Server Error
