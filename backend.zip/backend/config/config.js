
const path = require('path');
const { argv } = require('yargs');

const env = argv.env || 'development';
require('dotenv').config({ path: path.join(__dirname, `env/${env}.env`) });

module.exports = {
  app: {
    name: process.env.APP_NAME || 'Zain Real Estate',
    port: process.env.PORT || 3000,
    env: process.env.NODE_ENV || 'development'
  },
  database: require('./database'),
  auth: require('./auth'),
  logging: {
    level: process.env.LOG_LEVEL || 'debug',
    dir: process.env.LOG_DIR || 'logs'
  }
};
