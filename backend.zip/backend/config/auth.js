
module.exports = {
  jwt: {
    secret: process.env.JWT_SECRET || 'super_secret_key',
    expiresIn: process.env.JWT_EXPIRES || '8h',
    issuer: process.env.JWT_ISSUER || 'zain-real-estate'
  },
  bcrypt: {
    saltRounds: process.env.BCRYPT_SALT_ROUNDS || 10
  },
  roles: {
    admin: 'admin',
    employee: 'employee',
    agent: 'agent'
  }
};
