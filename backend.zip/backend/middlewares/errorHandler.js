const { APIError } = require('../utils');
const logger = require('./logger');

const errorHandler = (err, req, res, next) => {
  let error = err;
  
  if (!(error instanceof APIError)) {
    error = new APIError({
      status: err.status || 500,
      message: err.message || 'خطأ في الخادم',
      error: err
    });
  }

  logger.error(`${error.status} - ${error.message} - ${req.originalUrl}`);

  res.status(error.status).json({
    success: false,
    error: {
      code: error.code || 'SERVER_ERROR',
      message: error.message,
      ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
    }
  });
};

module.exports = errorHandler;