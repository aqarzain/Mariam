const { APIError } = require('../utils');

const authorize = (roles = []) => {
  if (typeof roles === 'string') {
    roles = [roles];
  }

  return (req, res, next) => {
    try {
      if (!roles.includes(req.user.role.role_name)) {
        throw new APIError({
          status: 403,
          message: 'غير مصرح بالوصول'
        });
      }
      next();
    } catch (error) {
      next(error);
    }
  };
};

module.exports = authorize;