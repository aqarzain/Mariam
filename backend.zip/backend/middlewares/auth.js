const jwt = require('jsonwebtoken');
const { APIError } = require('../utils');
const { User } = require('../models');
const { auth } = require('../config/config');

const authenticate = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      throw new APIError({
        status: 401,
        message: 'مطلوب مصادقة'
      });
    }

    const decoded = jwt.verify(token, auth.jwt.secret);
    const user = await User.findByPk(decoded.user_id);

    if (!user || !user.is_active) {
      throw new APIError({
        status: 401,
        message: 'الحساب غير مفعل أو غير موجود'
      });
    }

    req.user = user;
    next();
  } catch (error) {
    next(new APIError({
      status: 401,
      message: 'جلسة غير صالحة',
      error
    }));
  }
};

module.exports = authenticate;