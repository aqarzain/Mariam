const { Op } = require('sequelize');

const buildWhereClause = (query) => {
  const where = {};
  
  if (query.minPrice || query.maxPrice) {
    where.price = {};
    if (query.minPrice) where.price[Op.gte] = query.minPrice;
    if (query.maxPrice) where.price[Op.lte] = query.maxPrice;
  }

  if (query.city) {
    where.city = query.city;
  }

  return where;
};

const buildPagination = (query) => {
  const page = parseInt(query.page) || 1;
  const limit = parseInt(query.limit) || 10;
  const offset = (page - 1) * limit;

  return { page, limit, offset };
};

module.exports = { buildWhereClause, buildPagination };