const fs = require('fs');
const path = require('path');
const { promisify } = require('util');

const unlinkAsync = promisify(fs.unlink);

const deleteFile = async (filePath) => {
  try {
    const fullPath = path.join(__dirname, '../../', filePath);
    await unlinkAsync(fullPath);
    return true;
  } catch (error) {
    throw new Error('فشل في حذف الملف');
  }
};

const validateFileType = (file, allowedTypes) => {
  const fileType = file.mimetype.split('/')[0];
  return allowedTypes.includes(fileType);
};

module.exports = { deleteFile, validateFileType };