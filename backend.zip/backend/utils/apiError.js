class APIError extends Error {
  constructor({
    status = 500,
    message = 'خطأ في الخادم',
    code = 'SERVER_ERROR',
    errors = null
  }) {
    super(message);
    this.name = this.constructor.name;
    this.status = status;
    this.code = code;
    this.errors = errors;
    Error.captureStackTrace(this, this.constructor);
  }

  static format(error) {
    return {
      success: false,
      error: {
        code: error.code,
        message: error.message,
        ...(error.errors && { errors: error.errors })
      }
    };
  }
}

module.exports = APIError;