const APIError = require('./apiError');
const { successResponse, errorResponse, paginatedResponse } = require('./apiResponse');
const { formatDate, calculateDuration, isDateInFuture } = require('./dateUtils');
const { buildWhereClause, buildPagination } = require('./queryUtils');
const { deleteFile, validateFileType } = require('./fileUtils');
const {
  validateEgyptianPhone,
  validatePassword,
  validateCoordinates
} = require('./validationUtils');

module.exports = {
  APIError,
  successResponse,
  errorResponse,
  paginatedResponse,
  formatDate,
  calculateDuration,
  isDateInFuture,
  buildWhereClause,
  buildPagination,
  deleteFile,
  validateFileType,
  validateEgyptianPhone,
  validatePassword,
  validateCoordinates
};