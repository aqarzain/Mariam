const APIError = require('./apiError');

const successResponse = (res, data, status = 200) => {
  res.status(status).json({
    success: true,
    data
  });
};

const errorResponse = (res, error) => {
  const formattedError = APIError.format(error);
  res.status(error.status || 500).json(formattedError);
};

const paginatedResponse = (res, data, pagination) => {
  res.status(200).json({
    success: true,
    data,
    pagination: {
      page: pagination.page,
      limit: pagination.limit,
      total: pagination.total
    }
  });
};

module.exports = { successResponse, errorResponse, paginatedResponse };