const moment = require('moment');
require('moment/locale/ar');

const formatDate = (date, format = 'YYYY-MM-DD HH:mm') => {
  return moment(date).locale('ar').format(format);
};

const calculateDuration = (startDate, endDate) => {
  const start = moment(startDate);
  const end = moment(endDate);
  return end.diff(start, 'days') + 1;
};

const isDateInFuture = (date) => {
  return moment(date).isAfter(moment());
};

module.exports = { formatDate, calculateDuration, isDateInFuture };