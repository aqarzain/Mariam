const validateEgyptianPhone = (phone) => {
  return /^01[0-9]{9}$/.test(phone);
};

const validatePassword = (password) => {
  return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/.test(password);
};

const validateCoordinates = (lat, lng) => {
  return (
    lat >= -90 && lat <= 90 &&
    lng >= -180 && lng <= 180
  );
};

module.exports = {
  validateEgyptianPhone,
  validatePassword,
  validateCoordinates
};