const { DataTypes, Sequelize } = require('sequelize');

module.exports = (sequelize) => {
  const Payment = sequelize.define('Payment', {
    payment_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      comment: 'المعرف الفريد للدفعة'
    },
    amount: {
      type: DataTypes.DECIMAL(12, 2),
      allowNull: false,
      validate: {
        isDecimal: {
          msg: 'المبلغ يجب أن يكون رقم عشري'
        },
        min: {
          args: [0.01],
          msg: 'المبلغ يجب أن يكون أكبر من الصفر'
        }
      }
    },
    payment_method: {
      type: DataTypes.ENUM('cash', 'vodafone_cash', 'bank_transfer'),
      allowNull: false,
      validate: {
        isIn: {
          args: [['cash', 'vodafone_cash', 'bank_transfer']],
          msg: 'طريقة الدفع غير صالحة'
        }
      }
    },
    transaction_id: {
      type: DataTypes.STRING(255),
      unique: {
        name: 'unique_transaction_id',
        msg: 'رقم المعاملة مسجل مسبقاً'
      },
      validate: {
        notEmpty: {
          msg: 'رقم المعاملة مطلوب'
        }
      }
    },
    payment_date: {
      type: DataTypes.DATE,
      defaultValue: Sequelize.NOW,
      validate: {
        isDate: {
          msg: 'تاريخ الدفع غير صالح'
        }
      }
    }
  }, {
    timestamps: false,
    paranoid: false,
    indexes: [
      {
        fields: ['transaction_id'],
        unique: true
      },
      {
        fields: ['payment_date']
      }
    ],
    hooks: {
      beforeValidate: (payment) => {
        if (payment.transaction_id) {
          payment.transaction_id = payment.transaction_id.trim().toUpperCase();
        }
      },
      beforeCreate: (payment) => {
        if (!payment.payment_date) {
          payment.payment_date = new Date();
        }
      }
    }
  });

  // العلاقات
  Payment.associate = ({ Contract }) => {
    Payment.belongsTo(Contract, {
      foreignKey: {
        name: 'contract_id',
        allowNull: false
      },
      onDelete: 'RESTRICT',
      onUpdate: 'CASCADE'
    });
  };

  // دالة التحقق من المعاملة
  Payment.verifyTransaction = async (transactionId) => {
    return await Payment.findOne({
      where: { transaction_id: transactionId }
    });
  };

  // دالة الحصول على إجمالي المدفوعات
  Payment.prototype.getTotalPayments = async function() {
    return await Payment.sum('amount', {
      where: { contract_id: this.contract_id }
    });
  };

  // دالة البحث بالتاريخ
  Payment.findByDate = async (startDate, endDate) => {
    return await Payment.findAll({
      where: {
        payment_date: {
          [Sequelize.Op.between]: [startDate, endDate]
        }
      }
    });
  };

  return Payment;
};