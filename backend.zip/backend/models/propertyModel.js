const { DataTypes, Sequelize } = require('sequelize');

module.exports = (sequelize) => {
  const Property = sequelize.define('Property', {
    property_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      comment: 'المعرف الفريد للعقار'
    },
    title: {
      type: DataTypes.STRING(255),
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'عنوان العقار مطلوب'
        },
        len: {
          args: [5, 255],
          msg: 'العنوان يجب أن يكون بين 5 و255 حرف'
        }
      }
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'عنوان التفصيلي مطلوب'
        }
      }
    },
    city: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
        isIn: {
          args: [['القاهرة', 'الجيزة', 'الإسكندرية', 'المنصورة']],
          msg: 'المدينة غير مسجلة'
        }
      }
    },
    price: {
      type: DataTypes.DECIMAL(12, 2),
      validate: {
        isDecimal: {
          msg: 'السعر يجب أن يكون رقم عشري'
        },
        min: {
          args: [0.01],
          msg: 'السعر يجب أن يكون أكبر من الصفر'
        }
      }
    },
    area: {
      type: DataTypes.DECIMAL(8, 2),
      validate: {
        isDecimal: {
          msg: 'المساحة يجب أن تكون رقم عشري'
        },
        min: {
          args: [0.01],
          msg: 'المساحة يجب أن تكون أكبر من الصفر'
        }
      }
    },
    latitude: {
      type: DataTypes.DECIMAL(9, 6),
      validate: {
        isFloat: {
          args: { min: -90, max: 90 },
          msg: 'خط العرض غير صالح'
        }
      }
    },
    longitude: {
      type: DataTypes.DECIMAL(9, 6),
      validate: {
        isFloat: {
          args: { min: -180, max: 180 },
          msg: 'خط الطول غير صالح'
        }
      }
    },
    status: {
      type: DataTypes.ENUM('available', 'reserved', 'sold'),
      defaultValue: 'available',
      validate: {
        isIn: {
          args: [['available', 'reserved', 'sold']],
          msg: 'حالة العقار غير صالحة'
        }
      }
    }
  }, {
    timestamps: false,
    indexes: [
      {
        fields: ['city']
      },
      {
        fields: ['price']
      },
      {
        fields: ['status']
      },
      {
        fields: ['latitude', 'longitude'],
        using: 'GIST'
      }
    ],
    hooks: {
      beforeValidate: (property) => {
        if (property.city) {
          property.city = property.city.trim();
        }
      }
    }
  });

  // العلاقات
  Property.associate = ({ Contract }) => {
    Property.hasMany(Contract, {
      foreignKey: 'property_id',
      onDelete: 'RESTRICT',
      onUpdate: 'CASCADE'
    });
  };

  // دالة التحقق من التوفر
  Property.prototype.isAvailable = function() {
    return this.status === 'available';
  };

  // دالة البحث العقارات في نطاق سعري
  Property.findByPriceRange = async (min, max) => {
    return await Property.findAll({
      where: {
        price: {
          [Sequelize.Op.between]: [min, max]
        }
      },
      order: [['price', 'ASC']]
    });
  };

  // دالة تحديث حالة العقار
  Property.prototype.updateStatus = async function(newStatus) {
    this.status = newStatus;
    return await this.save();
  };

  return Property;
};