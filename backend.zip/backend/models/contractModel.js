const { DataTypes, Sequelize } = require('sequelize');

module.exports = (sequelize) => {
  const Contract = sequelize.define('Contract', {
    contract_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      comment: 'المعرف الفريد للعقد'
    },
    start_date: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      validate: {
        isDate: {
          msg: 'تاريخ البداية يجب أن يكون تاريخ صحيح'
        },
        notEmpty: {
          msg: 'تاريخ بداية العقد مطلوب'
        }
      }
    },
    end_date: {
      type: DataTypes.DATEONLY,
      validate: {
        isDate: {
          msg: 'تاريخ النهاية يجب أن يكون تاريخ صحيح'
        },
        isValidEndDate(value) {
          if (this.contract_type === 'rent' && !value) {
            throw new Error('تاريخ النهاية مطلوب لعقود الإيجار');
          }
          if (this.contract_type === 'sale' && value) {
            throw new Error('عقود البيع لا تحتاج لتاريخ نهاية');
          }
          if (value && value < this.start_date) {
            throw new Error('تاريخ النهاية لا يمكن أن يكون قبل تاريخ البداية');
          }
        }
      }
    },
    contract_type: {
      type: DataTypes.ENUM('sale', 'rent'),
      allowNull: false,
      validate: {
        isIn: {
          args: [['sale', 'rent']],
          msg: 'نوع العقد يجب أن يكون إما sale أو rent'
        }
      }
    }
  }, {
    timestamps: false,
    paranoid: true,
    indexes: [
      {
        fields: ['contract_type']
      },
      {
        fields: ['start_date', 'end_date']
      }
    ],
    hooks: {
      beforeValidate: (contract) => {
        // تحويل النوع إلى أحرف صغيرة
        if (contract.contract_type) {
          contract.contract_type = contract.contract_type.toLowerCase();
        }
        
        // معالجة التواريخ
        if (contract.start_date) {
          contract.start_date = new Date(contract.start_date).toISOString().split('T')[0];
        }
        if (contract.end_date) {
          contract.end_date = new Date(contract.end_date).toISOString().split('T')[0];
        }
      }
    }
  });

  // العلاقات
  Contract.associate = ({ Client, Property, Payment }) => {
    Contract.belongsTo(Client, {
      foreignKey: {
        name: 'client_id',
        allowNull: false
      },
      onDelete: 'RESTRICT',
      onUpdate: 'CASCADE'
    });

    Contract.belongsTo(Property, {
      foreignKey: {
        name: 'property_id',
        allowNull: false
      },
      onDelete: 'RESTRICT',
      onUpdate: 'CASCADE'
    });

    Contract.hasMany(Payment, {
      foreignKey: 'contract_id',
      onDelete: 'SET NULL',
      onUpdate: 'CASCADE'
    });
  };

  // دالة مساعدة للتحقق من العقد النشط
  Contract.prototype.isActive = function() {
    const today = new Date();
    const start = new Date(this.start_date);
    const end = this.end_date ? new Date(this.end_date) : null;
    
    return this.contract_type === 'rent' 
      ? today >= start && today <= end
      : today >= start;
  };

  // دالة بحث بالتاريخ
  Contract.findByDateRange = async (start, end) => {
    return await Contract.findAll({
      where: {
        start_date: { [Sequelize.Op.gte]: start },
        end_date: { [Sequelize.Op.lte]: end }
      }
    });
  };

  return Contract;
};