const { DataTypes } = require('sequelize');
const { validatePhone } = require('./validators/phone.validator');

module.exports = (sequelize) => {
  const Client = sequelize.define('Client', {
    client_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      comment: 'المعرف الفريد للعميل'
    },
    full_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'اسم العميل مطلوب'
        },
        len: {
          args: [3, 255],
          msg: 'الاسم يجب أن يكون بين 3 و255 حرف'
        }
      }
    },
    phone: {
      type: DataTypes.STRING(20),
      unique: {
        name: 'unique_client_phone',
        msg: 'رقم الهاتف مسجل مسبقاً'
      },
      validate: {
        isEgyptianPhone: validatePhone
      },
      comment: 'رقم هاتف مصري صالح'
    },
    preferences: {
      type: DataTypes.JSONB,
      defaultValue: {},
      validate: {
        isValidPreferences(value) {
          try {
            JSON.parse(JSON.stringify(value));
          } catch (e) {
            throw new Error('التفضيلات يجب أن تكون بيانات JSON صالحة');
          }
        }
      },
      comment: 'تفضيلات العميل بتنسيق JSON'
    }
  }, {
    timestamps: false,
    paranoid: false,
    indexes: [
      {
        fields: ['phone'],
        unique: true
      }
    ],
    hooks: {
      beforeValidate: (client) => {
        if (client.phone) {
          client.phone = client.phone.trim().replace(/\s+/g, '');
        }
      }
    }
  });

  Client.associate = ({ Contract }) => {
    Client.hasMany(Contract, {
      foreignKey: 'client_id',
      onDelete: 'RESTRICT',
      onUpdate: 'CASCADE'
    });
  };

  // دالة مساعدة للبحث بالهاتف
  Client.findByPhone = async (phone) => {
    return await Client.findOne({
      where: { phone: phone.trim() }
    });
  };

  // دالة لتحديث التفضيلات
  Client.prototype.updatePreferences = async function(newPreferences) {
    this.preferences = { ...this.preferences, ...newPreferences };
    return await this.save();
  };

  return Client;
};