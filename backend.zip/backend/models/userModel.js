const { DataTypes } = require('sequelize');
const bcrypt = require('bcrypt');
const { validatePhone } = require('./validators/phone.validator');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    user_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      comment: 'المعرف الفريد للمستخدم'
    },
    full_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
      validate: {
        notEmpty: {
          msg: 'الاسم الكامل مطلوب'
        },
        len: {
          args: [3, 255],
          msg: 'الاسم يجب أن يكون بين 3 و255 حرف'
        }
      }
    },
    phone: {
      type: DataTypes.STRING(20),
      unique: {
        name: 'unique_user_phone',
        msg: 'رقم الهاتف مسجل مسبقاً'
      },
      allowNull: false,
      validate: {
        isEgyptianPhone: validatePhone
      }
    },
    password: {
      type: DataTypes.TEXT,
      allowNull: false,
      validate: {
        isStrongPassword(value) {
          if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/.test(value)) {
            throw new Error('كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، حرف كبير وصغير ورقم');
          }
        }
      }
    },
    role_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      validate: {
        isInt: {
          msg: 'معرف الدور يجب أن يكون رقم صحيح'
        }
      }
    },
    is_active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
      comment: 'حالة تفعيل الحساب'
    }
  }, {
    timestamps: true,
    createdAt: 'created_at',
    updatedAt: 'updated_at',
    paranoid: true,
    defaultScope: {
      attributes: { exclude: ['password'] }
    },
    scopes: {
      withPassword: {
        attributes: {}
      }
    },
    hooks: {
      beforeCreate: async (user) => {
        user.password = await bcrypt.hash(user.password, 10);
      },
      beforeUpdate: async (user) => {
        if (user.changed('password')) {
          user.password = await bcrypt.hash(user.password, 10);
        }
      }
    },
    indexes: [
      {
        fields: ['phone'],
        unique: true
      },
      {
        fields: ['role_id']
      }
    ]
  });

  // العلاقات
  User.associate = ({ Role }) => {
    User.belongsTo(Role, {
      foreignKey: 'role_id',
      onDelete: 'RESTRICT',
      onUpdate: 'CASCADE'
    });
  };

  // دالة المقارنة
  User.prototype.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
  };

  // دالة التفعيل
  User.prototype.activate = async function() {
    this.is_active = true;
    return await this.save();
  };

  // دالة التعطيل
  User.prototype.deactivate = async function() {
    this.is_active = false;
    return await this.save();
  };

  // دالة البحث بالهاتف
  User.findByPhone = async (phone) => {
    return await User.scope('withPassword').findOne({
      where: { phone: phone.trim() }
    });
  };

  return User;
};