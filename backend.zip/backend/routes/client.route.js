const router = require('express').Router();
const { clientController } = require('../controllers');
const { auth, authorize } = require('../middlewares');

// مثال افتراضي لمسارات العملاء
router.get('/',
  auth,
  authorize(['admin', 'agent']),
  clientController.getAllClients
);

router.post('/',
  auth,
  authorize(['admin', 'agent']),
  clientController.createClient
);

module.exports = router;