const router = require('express').Router();

router.use('/auth', require('./auth.route'));
router.use('/properties', require('./property.route'));
router.use('/contracts', require('./contract.route'));
router.use('/users', require('./user.route'));
router.use('/clients', require('./client.route'));
router.use('/payments', require('./payment.route'));

module.exports = router;