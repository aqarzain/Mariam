# وثائق مسارات API

## المصادقة
- `POST /auth/login` - تسجيل الدخول
- `POST /auth/register` - تسجيل مستخدم جديد

## العقارات
- `GET /properties` - قائمة جميع العقارات
- `GET /properties/available` - العقارات المتاحة
- `POST /properties` - إضافة عقار جديد (يتطلب صلاحية مدير/وسيط)

## العقود
- `POST /contracts` - إنشاء عقد جديد
- `DELETE /contracts/:id` - إنهاء عقد (صلاحية مدير فقط)

## نمط الاستجابة
```json
{
  "success": boolean,
  "data": object|null,
  "error": {
    "code": string,
    "message": string
  }|null
}
```