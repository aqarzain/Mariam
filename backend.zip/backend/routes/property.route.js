const router = require('express').Router();
const { propertyController } = require('../controllers');
const { auth, authorize } = require('../middlewares');

router.get('/', propertyController.getAllProperties);
router.get('/available', propertyController.getAvailableProperties);

router.post('/',
  auth,
  authorize(['admin', 'agent']),
  propertyController.createProperty
);

router.patch('/:id/status',
  auth,
  authorize(['admin', 'agent']),
  propertyController.updatePropertyStatus
);

module.exports = router;