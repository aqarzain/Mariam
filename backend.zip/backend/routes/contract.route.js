const router = require('express').Router();
const { contractController } = require('../controllers');
const { auth, authorize } = require('../middlewares');

router.post('/',
  auth,
  authorize(['admin', 'agent']),
  contractController.createContract
);

router.delete('/:id',
  auth,
  authorize(['admin']),
  contractController.terminateContract
);

module.exports = router;