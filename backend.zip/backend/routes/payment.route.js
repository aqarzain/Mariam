const router = require('express').Router();
const { paymentController } = require('../controllers');
const { auth } = require('../middlewares');

router.post('/',
  auth,
  paymentController.createPayment
);

router.get('/report',
  auth,
  paymentController.generatePaymentReport
);

module.exports = router;