const router = require('express').Router();
const { authController } = require('../controllers');
const { authValidation } = require('../validations');

router.post('/login', 
  authValidation.validateLogin,
  authController.login
);

router.post('/register', 
  authValidation.validateRegistration,
  authController.register
);

router.post('/refresh-token', 
  authController.refreshToken
);

module.exports = router;