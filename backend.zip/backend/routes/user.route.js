const router = require('express').Router();
const { userController } = require('../controllers');
const { auth, authorize } = require('../middlewares');

router.get('/',
  auth,
  authorize(['admin']),
  userController.getAllUsers
);

router.patch('/:id/status',
  auth,
  authorize(['admin']),
  userController.toggleUserStatus
);

module.exports = router;