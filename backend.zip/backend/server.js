#!/usr/bin/env node
const http = require('http');
const { app } = require('./app');
const { logger } = require('./middlewares');
const { config } = require('./config/config');

// إنشاء خادم HTTP
const server = http.createServer(app);

// تهيئة المنفذ من المتغيرات البيئية أو القيمة الافتراضية
const port = normalizePort(config.app.port || '3000');
app.set('port', port);

// معالجة أخطاء الخادم
server.on('error', (error) => {
  if (error.syscall !== 'listen') throw error;
  
  const bind = typeof port === 'string' ? `Pipe ${port}` : `Port ${port}`;
  
  switch (error.code) {
    case 'EACCES':
      logger.error(`${bind} requires elevated privileges`);
      process.exit(1);
      break;
    case 'EADDRINUSE':
      logger.error(`${bind} is already in use`);
      process.exit(1);
      break;
    default:
      throw error;
  }
});

// بدء الاستماع على المنفذ
server.listen(port, () => {
  const addr = server.address();
  const bind = typeof addr === 'string' ? `pipe ${addr}` : `port ${addr.port}`;
  logger.info(`🚀 Server running in ${config.app.env} mode on ${bind}`);
});

// معالجة الإشارات لإغلاق نظيف
const shutdownSignals = ['SIGINT', 'SIGTERM', 'SIGQUIT'];

shutdownSignals.forEach(signal => {
  process.on(signal, () => {
    logger.warn(`⚠️  Received ${signal}. Closing server...`);
    
    server.close(async (err) => {
      if (err) {
        logger.error('❌ Server closure error:', err);
        process.exit(1);
      }
      
      // إضافة أي عمليات تنظيف إضافية هنا
      logger.info('✅ Server closed successfully');
      process.exit(0);
    });
  });
});

// تطبيع رقم المنفذ
function normalizePort(val) {
  const port = parseInt(val, 10);

  if (Number.isNaN(port)) return val;
  if (port >= 0) return port;
  
  return false;
}

module.exports = { server };