-- دالة تحديث الطابع الزمني
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- دالة إدارة حالة العقار (مطوّرة)
CREATE OR REPLACE FUNCTION update_property_status()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF NEW.contract_type = 'sale' THEN
            UPDATE properties SET status = 'sold' WHERE property_id = NEW.property_id;
        ELSE
            UPDATE properties SET status = 'reserved' WHERE property_id = NEW.property_id;
        END IF;
    ELSIF TG_OP = 'DELETE' THEN
        IF NOT EXISTS (SELECT 1 FROM contracts WHERE property_id = OLD.property_id) THEN
            UPDATE properties SET status = 'available' WHERE property_id = OLD.property_id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- دالة جديدة للتحديثات على العقود
CREATE OR REPLACE FUNCTION update_property_status_on_update()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.contract_type <> OLD.contract_type THEN
        IF NEW.contract_type = 'sale' THEN
            UPDATE properties SET status = 'sold' WHERE property_id = NEW.property_id;
        ELSE
            UPDATE properties SET status = 'reserved' WHERE property_id = NEW.property_id;
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;