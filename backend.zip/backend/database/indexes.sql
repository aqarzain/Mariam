-- فهارس العقارات
CREATE INDEX IF NOT EXISTS idx_properties_price ON properties(price);
CREATE INDEX IF NOT EXISTS idx_properties_location ON properties(latitude, longitude);

-- فهارس العملاء
CREATE INDEX IF NOT EXISTS idx_clients_phone ON clients(phone);

-- فهارس العقود
CREATE INDEX IF NOT EXISTS idx_contracts_dates ON contracts(start_date, end_date);