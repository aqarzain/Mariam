-- تحديث الوقت التلقائي للمستخدمين
CREATE TRIGGER users_update_trigger
BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION update_timestamp();

-- إدارة حالة العقار عند التعاقد
CREATE TRIGGER contracts_property_status_trigger
AFTER INSERT OR DELETE ON contracts
FOR EACH ROW EXECUTE FUNCTION update_property_status();

-- إدارة حالة العقار عند تعديل العقد
CREATE TRIGGER contracts_update_property_status_trigger
AFTER UPDATE ON contracts
FOR EACH ROW EXECUTE FUNCTION update_property_status_on_update();