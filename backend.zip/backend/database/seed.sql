-- إضافة الأدوار الأساسية
INSERT INTO roles (role_name) VALUES 
('admin'), 
('employee'), 
('agent')
ON CONFLICT (role_name) DO NOTHING;

-- إضافة المستخدم الإداري (كلمة المرور: Admin@1234)
INSERT INTO users (full_name, phone, password, role_id) 
VALUES (
    'المدير العام',
    '01000000001',
    crypt('Admin@1234', gen_salt('bf')),
    (SELECT role_id FROM roles WHERE role_name = 'admin')
)
ON CONFLICT (phone) DO NOTHING;

-- عينات اختبارية للعقارات
INSERT INTO properties (title, address, city, price, area) VALUES
('فيلا فاخرة', 'حي الرحاب، القاهرة', 'القاهرة', 5000000, 350),
('شقة للايجار', 'مدينة نصر، القاهرة', 'القاهرة', 12000, 120);