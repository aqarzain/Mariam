CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- جدول الأدوار
CREATE TABLE IF NOT EXISTS roles (
    role_id SERIAL PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL CHECK (role_name IN ('admin', 'employee', 'agent'))
);

-- جدول المستخدمين
CREATE TABLE IF NOT EXISTS users (
    user_id SERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) UNIQUE CHECK (phone ~ '^01[0-9]{9}$'),
    password TEXT NOT NULL,
    role_id INT NOT NULL REFERENCES roles(role_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- جدول العملاء
CREATE TABLE IF NOT EXISTS clients (
    client_id SERIAL PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) CHECK (phone ~ '^01[0-9]{9}$'),
    preferences JSONB
);

-- جدول العقارات
CREATE TABLE IF NOT EXISTS properties (
    property_id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    price NUMERIC(12,2) CHECK (price > 0),
    area NUMERIC(8,2) CHECK (area > 0),
    latitude NUMERIC(9,6),
    longitude NUMERIC(9,6),
    status VARCHAR(20) DEFAULT 'available' CHECK (status IN ('available', 'reserved', 'sold'))
);

-- جدول العقود (محدث)
CREATE TABLE IF NOT EXISTS contracts (
    contract_id SERIAL PRIMARY KEY,
    client_id INT NOT NULL REFERENCES clients(client_id),
    property_id INT NOT NULL REFERENCES properties(property_id),
    start_date DATE NOT NULL,
    end_date DATE CHECK (
        (contract_type = 'rent' AND end_date >= start_date) OR
        (contract_type = 'sale' AND end_date IS NULL)
    ),
    contract_type VARCHAR(20) NOT NULL CHECK (contract_type IN ('sale', 'rent')),
    CONSTRAINT check_rent_end_date CHECK (
        (contract_type = 'rent' AND end_date IS NOT NULL) OR
        (contract_type = 'sale' AND end_date IS NULL)
    )
);

-- جدول المدفوعات
CREATE TABLE IF NOT EXISTS payments (
    payment_id SERIAL PRIMARY KEY,
    contract_id INT NOT NULL REFERENCES contracts(contract_id),
    amount NUMERIC(12,2) CHECK (amount > 0),
    payment_method VARCHAR(50) CHECK (payment_method IN ('cash', 'vodafone_cash', 'bank_transfer')),
    transaction_id VARCHAR(255) UNIQUE,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);