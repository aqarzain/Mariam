# قاعدة بيانات عقار زين

## متطلبات النظام
- PostgreSQL 12 أو أعلى
- إضافة pgcrypto

## إعداد القاعدة
```bash
# إنشاء المستخدم والقاعدة
sudo -u postgres psql -c "CREATE USER zain_user WITH PASSWORD 'AShmhER22';"
sudo -u postgres psql -c "CREATE DATABASE zain_db OWNER zain_user;"

# تشغيل السكربتات بالترتيب:
psql -h localhost -U zain_user -d zain_db -f init.sql
psql -h localhost -U zain_user -d zain_db -f functions.sql
psql -h localhost -U zain_user -d zain_db -f triggers.sql
psql -h localhost -U zain_user -d zain_db -f indexes.sql
psql -h localhost -U zain_user -d zain_db -f seed.sql