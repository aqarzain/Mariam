require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { config } = require('./config');
const routes = require('./routes');
const { errorHandler, logger } = require('./middlewares');

const app = express();

// ============ Middlewares الأساسية ============
app.use(helmet());
app.use(cors({
  origin: config.app.env === 'production' ? 
    ['https://zain-realestate.com', 'https://admin.zain-realestate.com'] :
    'http://localhost:3000',
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

// ============ تسجيل الطلبات ============
if (config.app.env !== 'test') {
  app.use(morgan(config.app.env === 'development' ? 'dev' : 'combined', {
    stream: {
      write: (message) => logger.info(message.trim())
    }
  }));
}

// ============ مسارات API الرئيسية ============
app.use('/api/v1', routes);

// ============ التعامل مع 404 ============
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    error: {
      code: 'ROUTE_NOT_FOUND',
      message: 'المسار المطلوب غير موجود'
    }
  });
});

// ============ معالج الأخطاء النهائي ============
app.use(errorHandler);

// ============ تشغيل الخادم ============
const PORT = config.app.port || 8080;
const ENV = config.app.env.toUpperCase();
const server = app.listen(PORT, () => {
  logger.info(`[${ENV}] الخادم يعمل على المنفذ ${PORT}`);
});

// ============ إغلاق نظيف للخادم ============
const shutdown = (signal) => {
  logger.warn(`📴 Received ${signal}. Shutting down gracefully...`);
  server.close(() => {
    logger.info('🚫 Server closed');
    process.exit(0);
  });
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

module.exports = app;